package dao;

import util.DBUtil;

import java.sql.Connection;
import java.sql.Statement;

public class ModPDao {
    public String ModPassW(String username,String oldp,String newp) {
        String res="fail";
        try {
            DBUtil util =new DBUtil();
            Connection conn=util.getConnection();
            Statement stmt=util.getStatement(conn);
            String sql="update user set  password = '"+newp+"' where username='"+username+"' and password='"+oldp+"'";
            res = util.getSQLResult(sql, stmt);
            util.close(null, stmt, conn);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }


}