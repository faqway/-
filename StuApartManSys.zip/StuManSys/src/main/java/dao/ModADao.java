package dao;

import util.DBUtil;

import java.sql.Connection;
import java.sql.Statement;

import static java.lang.System.out;

public class ModADao {
    public String ModApart(String aid,String name,String cap) {
        DBUtil util = new DBUtil();
        Connection conn = util.getConnection();
        Statement stmt = util.getStatement(conn);
        String sql = "update apart set name = '"+name+"' ,Capacity = '"+cap+"' where AID = '"+aid+"' ;";
        out.println("Dao receive "+aid+cap);
        String result = util.getSQLResult(sql, stmt);
        util.close(null, stmt, conn);
        return result;
    }
}