package dao;

import util.DBUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class LoginDao {
    public String selectUser(String userName) {
        String rePwd = "";//返回给service的密码
        try {
            DBUtil util =new DBUtil();
            Connection conn=util.getConnection();
            Statement stmt=util.getStatement(conn);
            String sql="select * from user where username='"+userName+"'";
            ResultSet rs =  stmt.executeQuery(sql);
            while(rs.next()){
                rePwd = rs.getString("password");
            }

            util.close(rs, stmt, conn);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rePwd;
    }
}