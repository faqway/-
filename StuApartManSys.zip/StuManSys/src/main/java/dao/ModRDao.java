package dao;

import util.DBUtil;

import java.sql.Connection;
import java.sql.Statement;

import static java.lang.System.out;

public class ModRDao {
    public String ModR(String rid,String status) {
        DBUtil util = new DBUtil();
        Connection conn = util.getConnection();
        Statement stmt = util.getStatement(conn);
        out.println("Dao receive "+rid);
        String sql = "update repair set  Statuss = '已维修' where RID ='"+rid+"' ;";
        String result = util.getSQLResult(sql, stmt);
        util.close(null, stmt, conn);
        return result;
    }
}
