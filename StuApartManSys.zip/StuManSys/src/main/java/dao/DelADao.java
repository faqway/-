package dao;

import util.DBUtil;

import java.sql.Connection;
import java.sql.Statement;

import static java.lang.System.out;

public class DelADao {
    public String DelApart(String aid) {
        DBUtil util = new DBUtil();
        Connection conn = util.getConnection();
        Statement stmt = util.getStatement(conn);
        String sql = "delete from apart where AID like '"+aid+"'";
        out.println("Dao receive "+aid);
        String result = util.getSQLResult(sql, stmt);
        String sql2 = "update stu set AID = null,DorNum= null where AID like '"+aid+"'";
        result = util.getSQLResult(sql2, stmt);
        util.close(null, stmt, conn);
        return result;
    }
}