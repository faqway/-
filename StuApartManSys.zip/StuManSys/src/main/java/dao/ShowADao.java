package dao;

import util.DBUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

public class ShowADao {
    public ArrayList<HashMap<String, String>> selectAInfo() {
        // TODO Auto-generated method stub
        ArrayList<HashMap<String, String>> list = new ArrayList<>();
        try {
            DBUtil util = new DBUtil();
            //获取连接
            Connection conn = util.getConnection();
            //创建语句执行对象
            Statement stmt = util.getStatement(conn);
            String sql = "select * from apart order by AID asc;";

            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String aid = rs.getString("AID");
                String name = rs.getString("name");
                String loc = rs.getString("Location");
                String cap = rs.getString("Capacity");
                HashMap<String, String> map = new HashMap<String, String>();
                map.put("aid", aid);
                map.put("name", name);
                map.put("loc", loc);
                map.put("cap", cap);
                list.add(map);
            }
            util.close(rs, stmt, conn);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return list;
    }
}