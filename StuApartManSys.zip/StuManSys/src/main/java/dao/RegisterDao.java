package dao;

import util.DBUtil;

import java.sql.Connection;
import java.sql.Statement;

public class RegisterDao {
    public String insertUser(String name,String pwd) {
        String res="fail";
        try {
            DBUtil util =new DBUtil();
            Connection conn=util.getConnection();
            Statement stmt=util.getStatement(conn);
            String sql="insert into user(username,password,type) values('" + name + "','" + pwd + "','2')";
            res = util.getSQLResult(sql, stmt);
            util.close(null, stmt, conn);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }


}
