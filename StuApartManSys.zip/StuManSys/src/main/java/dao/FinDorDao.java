package dao;

import util.DBUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import static java.lang.System.out;

public class FinDorDao {
    public ArrayList<HashMap<String, String>> DorInfo(String AID,String Dor) {
        // TODO Auto-generated method stub
        out.println(AID+Dor);
        ArrayList<HashMap<String, String>> list = new ArrayList<>();
        try {
            DBUtil util = new DBUtil();
            //获取连接
            Connection conn = util.getConnection();
            //创建语句执行对象
            Statement stmt = util.getStatement(conn);
            String sql = "select * from stu where AID = '"+AID+"' and DorNum ='"+Dor+"' ;";

            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                String sid = rs.getString("SID");
                String sname = rs.getString("SName");
                String aid = rs.getString("AID");
                String dornum = rs.getString("DorNum");
                HashMap<String, String> map = new HashMap<String, String>();
                map.put("sid", sid);
                map.put("sname", sname);
                map.put("aid", aid);
                map.put("dornum", dornum);
                list.add(map);
            }
            util.close(rs, stmt, conn);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return list;
    }
}
