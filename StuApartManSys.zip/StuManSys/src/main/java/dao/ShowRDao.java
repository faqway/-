package dao;

import util.DBUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

public class ShowRDao {
    public ArrayList<HashMap<String, String>> selectRInfo() {
        // TODO Auto-generated method stub
        ArrayList<HashMap<String, String>> list = new ArrayList<>();
        try {
            DBUtil util = new DBUtil();
            //获取连接
            Connection conn = util.getConnection();
            //创建语句执行对象
            Statement stmt = util.getStatement(conn);
            String sql = "select * from repair order by RID asc;";

            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String rid = rs.getString("RID");
                String sid = rs.getString("SID");
                String aid = rs.getString("AID");
                String dor = rs.getString("DorNum");
                String desc = rs.getString("descr");
                String status = rs.getString("statuss");
                String times = rs.getString("times");
                HashMap<String, String> map = new HashMap<String, String>();
                map.put("rid", rid);
                map.put("sid", sid);
                map.put("aid", aid);
                map.put("dor", dor);
                map.put("desc", desc);
                map.put("status", status);
                map.put("times", times);
                list.add(map);
            }
            util.close(rs, stmt, conn);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return list;
    }
}