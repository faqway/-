package dao;

import util.DBUtil;

import java.sql.Connection;
import java.sql.Statement;

import static java.lang.System.out;

public class AddDao {
    public String addStu(String sid, String sName, String aid, String dorNum) {
        DBUtil util = new DBUtil();
        Connection conn = util.getConnection();
        Statement stmt = util.getStatement(conn);
        String sql = "insert into stu(SID,SName,AID,dorNum) values("+sid+",'"
                +sName+"',"+aid+","+dorNum+")";
        out.println("Dao receive "+sid+sName+aid+"#"+dorNum);
        String result = util.getSQLResult(sql, stmt);
        String sql2 = "insert into user(username,password,type) values("+sid+","+123456+",2)";
        result = util.getSQLResult(sql2, stmt);
        util.close(null, stmt, conn);
        return result;
    }
}
