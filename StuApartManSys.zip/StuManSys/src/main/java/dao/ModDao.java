package dao;

import util.DBUtil;

import java.sql.Connection;
import java.sql.Statement;

import static java.lang.System.out;

public class ModDao {
    public String ModStu(String sid,String AID,String Dor) {
        DBUtil util = new DBUtil();
        Connection conn = util.getConnection();
        Statement stmt = util.getStatement(conn);
        String sql = "update stu set AID = '"+AID+"' ,DorNum = '"+Dor+"' where SID = '"+sid+"' ;";
        out.println("Dao receive "+sid);
        String result = util.getSQLResult(sql, stmt);
        util.close(null, stmt, conn);
        return result;
    }
}
