package dao;

import util.DBUtil;

import java.sql.Connection;
import java.sql.Statement;

import static java.lang.System.out;

public class AddADao {
    public String addApart(String aid, String location, String name, String Capacity) {
        DBUtil util = new DBUtil();
        Connection conn = util.getConnection();
        Statement stmt = util.getStatement(conn);
        String sql = "insert into apart(AID,Location,name,Capacity) values('"+aid+"','"
                +location+"','"+name+"','"+Capacity+"')";
        out.println("Dao receive "+aid);
        String result = util.getSQLResult(sql, stmt);
        util.close(null, stmt, conn);
        return result;
    }
}