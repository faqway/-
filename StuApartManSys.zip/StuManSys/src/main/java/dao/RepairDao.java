package dao;

import util.DBUtil;

import java.sql.Connection;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import static java.lang.System.out;

public class RepairDao {
    public String RepairApart(String SID, String AID, String DorNum, String Desc) {
        DBUtil util = new DBUtil();
        Connection conn = util.getConnection();
        Statement stmt = util.getStatement(conn);
        String sql = "insert into repair(SID,AID,DorNum,descr) values('"+ SID +"','"
                +AID+"','"+DorNum+"','"+Desc+"')";
        out.println("Repair Dao receive "+SID+AID+"#"+DorNum+Desc);
        String result = util.getSQLResult(sql, stmt);
        util.close(null, stmt, conn);
        return result;
    }
}
