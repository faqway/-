package service;

import dao.AddDao;
import dao.DelDao;

import static java.lang.System.out;

public class DelService {
    public String DelStu(String sid) {
        DelDao notedao=new DelDao();
        String res=notedao.DelStu(sid);
        out.println("Service receive "+sid);
        return res;
    }
}
