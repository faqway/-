package service;

import dao.DelDao;
import dao.ModDao;

import static java.lang.System.out;

public class ModService {
    public String ModStu(String sid,String AID,String Dor) {
        ModDao notedao=new ModDao();
        String res=notedao.ModStu(sid,AID,Dor);
        return res;
    }
}
