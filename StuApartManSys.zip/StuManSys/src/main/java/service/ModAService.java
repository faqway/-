package service;

import dao.DelDao;
import dao.ModADao;
import dao.ModDao;

import static java.lang.System.out;

public class ModAService {
    public String ModApart(String aid,String name,String capacity) {
        ModADao notedao=new ModADao();
        String res=notedao.ModApart(aid,name,capacity);
        return res;
    }
}