package service;

import dao.ModDao;
import dao.ModPDao;
import dao.ModRDao;

import static java.lang.System.out;

public class ModRService {
    public String ModR(String RID,String status) {
        ModRDao notedao=new ModRDao();
        String res=notedao.ModR(RID,status);
        out.println("RService"+RID);
        return res;
    }
}

