package service;

import dao.FinAIDao;
import dao.FinSIDao;

import  java.util.ArrayList;
import java.util.HashMap;
public class FinAIDService {
    public ArrayList<HashMap<String,String>> AIDInfo( String AID) {
        FinAIDao dao = new FinAIDao();
        ArrayList<HashMap<String,String>> list = dao.AIDInfo(AID);
        return list;
    }
}