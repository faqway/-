package service;

import dao.FinDorDao;
import dao.FinSIDao;

import  java.util.ArrayList;
import java.util.HashMap;
public class FinDorService {
    public ArrayList<HashMap<String,String>> DorInfo( String AID,String Dor) {
        FinDorDao dao = new FinDorDao();
        ArrayList<HashMap<String,String>> list = dao.DorInfo(AID,Dor);
        return list;
    }
}