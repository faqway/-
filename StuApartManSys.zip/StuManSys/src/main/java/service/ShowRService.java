package service;

import dao.ShowRDao;

import  java.util.ArrayList;
import java.util.HashMap;
public class ShowRService {
    public ArrayList<HashMap<String,String>> selectRInfo() {
        ShowRDao dao = new ShowRDao();
        ArrayList<HashMap<String,String>> list = dao.selectRInfo();
        return list;
    }
}