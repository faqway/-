package service;

import dao.ShowDao;

import  java.util.ArrayList;
import java.util.HashMap;
public class ShowService {
    public ArrayList<HashMap<String,String>> selectInfo() {
        ShowDao dao = new ShowDao();
        ArrayList<HashMap<String,String>> list = dao.selectInfo();
        return list;
    }
}
