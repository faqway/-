package service;

import dao.RegisterDao;

public class RegisterService {
    public String insert(String name,String pwd) {
        RegisterDao dao=new RegisterDao();
        String res=dao.insertUser(name, pwd);
        return res;
    }
}
