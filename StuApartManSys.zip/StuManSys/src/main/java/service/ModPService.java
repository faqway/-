package service;

import dao.ModDao;
import dao.ModPDao;

import static java.lang.System.out;

public class ModPService {
    public String ModPassW(String username,String oldp,String newp) {
        ModPDao notedao=new ModPDao();
        String res=notedao.ModPassW(username,oldp,newp);
        return res;
    }
}
