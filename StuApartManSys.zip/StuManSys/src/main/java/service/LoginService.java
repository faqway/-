package service;


import dao.LoginDao;

public class LoginService {
    public String login(String name,String pwd) {
        //浏览器和用户数据做比对
        LoginDao dao= new LoginDao();
        String dbPwd=dao.selectUser(name);
        //比对
        String res = "fail";//返回给servlet的结果
        if(pwd.equals(dbPwd)){
            res = "success";
        }
        return res;
    }
}
