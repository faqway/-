package service;

import dao.AddDao;
import dao.DelADao;
import dao.DelDao;

import static java.lang.System.out;

public class DelAService {
    public String DelApart(String aid) {
        DelADao notedao=new DelADao();
        String res=notedao.DelApart(aid);
        out.println("Service receive "+aid);
        return res;
    }
}