package service;

import dao.AddADao;

import static java.lang.System.out;

public class AddAService {
    public String addApart(String sid, String sName, String aid, String dorNum) {
        AddADao notedao=new AddADao();
        String res=notedao.addApart(sid,sName,aid,dorNum);
        out.println("Service receive "+sid+sName+aid+"#"+dorNum);
        return res;
    }
}