package service;

import dao.AddADao;
import dao.RepairDao;

import static java.lang.System.out;

public class RepairService {
    public String Repair(String SID,String AID,String DorNum,String Desc) {
        RepairDao notedao=new RepairDao();
        String res=notedao.RepairApart(SID,AID,DorNum,Desc);
        return res;
    }
}
