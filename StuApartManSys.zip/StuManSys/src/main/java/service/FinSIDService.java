package service;

import dao.FinSIDao;
import dao.ShowDao;

import  java.util.ArrayList;
import java.util.HashMap;
public class FinSIDService {
    public ArrayList<HashMap<String,String>> SIDInfo( String SID) {
        FinSIDao dao = new FinSIDao();
        ArrayList<HashMap<String,String>> list = dao.SIDInfo(SID);
        return list;
    }
}
