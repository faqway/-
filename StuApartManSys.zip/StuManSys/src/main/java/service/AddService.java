package service;

import dao.AddDao;

import static java.lang.System.out;

public class AddService {
    public String addStu(String sid, String sName, String aid, String dorNum) {
        AddDao notedao=new AddDao();
        String res=notedao.addStu(sid,sName,aid,dorNum);
        out.println("Service receive "+sid+sName+aid+"#"+dorNum);
        return res;
    }
}