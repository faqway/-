package service;

import dao.ShowADao;
import dao.ShowDao;

import  java.util.ArrayList;
import java.util.HashMap;
public class ShowAService {
    public ArrayList<HashMap<String,String>> selectAInfo() {
        ShowADao dao = new ShowADao();
        ArrayList<HashMap<String,String>> list = dao.selectAInfo();
        return list;
    }
}