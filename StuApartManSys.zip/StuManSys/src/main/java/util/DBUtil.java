package util;

import java.sql.*;

import static java.lang.System.out;

/**
 * DBUtil类提供了数据库连接、执行SQL语句和关闭数据库连接的功能
 */
public class DBUtil {

    /**
     * 获取数据库连接
     *
     * @return Connection对象，如果连接成功；否则返回null
     */
    public Connection getConnection() {
        Connection conn=null;
        try {
            // 加载并注册JDBC驱动
            Class.forName("com.mysql.cj.jdbc.Driver");
            // 定义数据库连接URL，包括数据库地址、端口、数据库名和字符编码参数
            String url="jdbc:mysql://localhost:3306/stumansys?useUnicode=true&characterEncoding=UTF-8";
            // 定义数据库用户名
            String dbUserName="root";
            // 定义数据库密码
            String dbUserpWD="root";
            // 通过DriverManager获取数据库连接
            conn=DriverManager.getConnection(url,dbUserName,dbUserpWD);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        out.println("DBUtil success");
        return conn;
    }

    /**
     * 获取Statement对象
     *
     * @param conn 数据库连接对象
     * @return Statement对象，如果创建成功；否则返回null
     */
    public Statement getStatement(Connection conn) {
        Statement stmt=null;
        try {
            // 创建Statement对象
            stmt=conn.createStatement();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return stmt;
    }

    /**
     * 执行SQL语句并获取执行结果
     *
     * @param sql 要执行的SQL语句
     * @param stmt Statement对象
     * @return 执行结果，成功返回"success"，否则返回"fail"
     */
    public String getSQLResult(String sql,Statement stmt ){
        String res = "fail";
        try {
            // 执行SQL语句并返回受影响的行数
            int a = stmt.executeUpdate(sql);
            // 如果受影响的行数不为0，表示执行成功
            if(a != 0){
                res = "success";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return res;
    }

    /**
     * 关闭数据库连接和相关资源
     *
     * @param rs ResultSet对象，可能为null
     * @param stmt Statement对象，可能为null
     * @param conn Connection对象，可能为null
     */
    public void close(ResultSet rs,Statement stmt,Connection conn) {
        try {
            // 关闭ResultSet
            if(rs!=null) {
                rs.close();
            }
            // 关闭Statement
            if(stmt!=null) {
                stmt.close();
            }
            // 关闭Connection
            if(conn!=null) {
                conn.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}
