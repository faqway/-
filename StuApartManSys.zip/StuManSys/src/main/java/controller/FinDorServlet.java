package controller;

import service.FinAIDService;
import service.FinDorService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

@WebServlet("/FinDorServlet")
public class FinDorServlet extends HttpServlet {
    public FinDorServlet()
    {
        super();
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        //1.数据传递

        FinDorService service = new FinDorService();

        String AID= request.getParameter("AID");
        String Dor= request.getParameter("Dor");

        //2.调用service
        ArrayList<HashMap<String,String>> list = service.DorInfo(AID, Dor);
        HttpSession session = request.getSession();
        session.setAttribute("list", list);

        response.sendRedirect("ShowStu.jsp");
    }
}
