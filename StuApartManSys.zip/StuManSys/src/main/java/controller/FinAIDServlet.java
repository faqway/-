package controller;

import service.FinAIDService;
import service.FinSIDService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

@WebServlet("/FinAIDServlet")
public class FinAIDServlet extends HttpServlet {
    public FinAIDServlet()
    {
        super();
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        //1.数据传递

        FinAIDService service = new FinAIDService();

        String AID= request.getParameter("AID");

        //2.调用service
        ArrayList<HashMap<String,String>> list = service.AIDInfo(AID);
        HttpSession session = request.getSession();
        session.setAttribute("list", list);

        response.sendRedirect("ShowStu.jsp");
    }
}