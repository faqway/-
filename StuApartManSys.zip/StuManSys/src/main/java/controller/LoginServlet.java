package controller;

import service.LoginService;
import util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.*;

import static java.lang.System.out;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session=request.getSession();

        session.invalidate();

        response.sendRedirect("login.jsp");
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.用户信息接收
        String userName=request.getParameter("username");
        String pwd=request.getParameter("pwd");
        //2.将数据传给service处理，并接受service处理结果
        LoginService service=new LoginService();
        String res=service.login(userName, pwd);
        if(res.equals("success")) {
            //用户信息存放在session
            HttpSession session=request.getSession();
            session.setAttribute("userName", userName);
            session.setAttribute("SID", userName);


            // 获取数据库连接
            DBUtil db = new DBUtil();
            Connection conn = db.getConnection();
            PreparedStatement stmt = null;
            ResultSet rs1 = null;

            try {
                //获取用户公寓宿舍号
                String sql1 = "SELECT * FROM stu WHERE SID = ?";
                stmt = conn.prepareStatement(sql1);
                stmt.setString(1, userName);  // 设置 SID 为 userName

                rs1 = stmt.executeQuery();

                if (rs1.next()) {  // 确保查询结果不为空
                    String AID = rs1.getString("AID");
                    String DorNum = rs1.getString("DorNum");

                    // 将结果存入 request 属性
                    request.setAttribute("AID", AID);
                    request.setAttribute("DorNum", DorNum);
                    session.setAttribute("AID", AID);
                    session.setAttribute("DorNum", DorNum);

                } else {
                    // 如果没有找到匹配的记录，处理为空的情况
                    request.setAttribute("AID", "无");
                    request.setAttribute("DorNum", "无");
                }

                // 获取宿舍和学生数量
                DBUtil db1 = new DBUtil();
                Connection conn1 = db1.getConnection();
                Statement stmt1 = db1.getStatement(conn);

// 查询宿舍数量
                String sqlDorms = "SELECT COUNT(*) AS dorm_count FROM apart";  // 假设宿舍信息保存在 dorm 表中
                ResultSet rsDorms = stmt1.executeQuery(sqlDorms);
                int dormCount = 0;
                if (rsDorms.next()) {
                    dormCount = rsDorms.getInt("dorm_count");
                }

// 查询学生数量
                String sqlStudents = "SELECT COUNT(*) AS student_count FROM stu";  // 假设学生信息保存在 stu 表中
                ResultSet rsStudents = stmt1.executeQuery(sqlStudents);
                int studentCount = 0;
                if (rsStudents.next()) {
                    studentCount = rsStudents.getInt("student_count");
                }

                String sqlrepairs = "SELECT COUNT(*) AS repair_count FROM repair";
                ResultSet rsrepairs = stmt1.executeQuery(sqlrepairs);
                int repairCount = 0;
                if (rsrepairs.next()) {
                    repairCount = rsrepairs.getInt("repair_count");
                }

                    // 将统计信息传递给 JSP 页面
                session.setAttribute("repairCount", repairCount);
                session.setAttribute("dormCount", dormCount);
                session.setAttribute("studentCount", studentCount);

                // 关闭资源
                db1.close(rsDorms, stmt1, conn1);

// 转发请求到首页 (index.jsp)
            } catch (SQLException e) {
                e.printStackTrace(); // 打印错误信息
            } finally {
                // 关闭资源
                db.close(rs1, stmt, conn);
            }

            //获取用户的权限
            // 获取数据库连接
            DBUtil db3 = new DBUtil();
            Connection conn3 = db3.getConnection();
            Statement stmt3 = db3.getStatement(conn3);

// 查询用户的身份类型
            String sql = "SELECT type FROM user WHERE  username= '" + userName + "'";  // 假设 `stu` 表存储了学生信息，并且有 `type` 字段
            ResultSet rs = null;
            try {
                rs = stmt3.executeQuery(sql);
                String userType;
                if (rs.next()) {  // 调用 rs.next()，将游标移到第一行
                    userType = rs.getString("type");  // 获取用户的身份类型
                } else {
                    // 如果没有找到用户的类型，设置默认值或处理
                    userType = "2";  // 默认为学生身份
                }
                session.setAttribute("type", userType);
                out.println(userType);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            // 关闭资源
            db3.close(rs, stmt3, conn3);

            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
        else {

            response.sendRedirect("login.jsp");
        }
        out.println(res);
    }


}