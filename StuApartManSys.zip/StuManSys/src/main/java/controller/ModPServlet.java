package controller;

import service.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static java.lang.System.out;


@WebServlet("/ModPServlet")
public class ModPServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModPServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");

        String username = request.getParameter("username");
        String oldp= request.getParameter("oldp");
        String newp= request.getParameter("newp");
        ModPService service =new ModPService();
        String res=service.ModPassW(username,oldp,newp);

        LoginService loginService=new LoginService();
        String result=loginService.login(username,newp);

        if(result.equals("success")){
            request.getRequestDispatcher("/login.jsp").forward(request,response);
        }else{
            request.setAttribute("error", "密码修改失败，请重新输入");
            request.getRequestDispatcher("/ModPassword.jsp").forward(request,response);
        }

    }
}