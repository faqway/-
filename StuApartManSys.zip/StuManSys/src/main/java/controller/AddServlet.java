package controller;

import service.AddService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static java.lang.System.out;


@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");

        String SID= request.getParameter("SID");
        String SName=request.getParameter("SName");
        String AID= request.getParameter("AID");
        String DorNum= request.getParameter("DorNum");
        AddService service =new AddService();
        String res=service.addStu(SID, SName, AID, DorNum);

        out.println("Servlet receive "+SID+SName+AID+"#"+DorNum);



        response.sendRedirect("AddShow");

    }
}