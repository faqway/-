package controller;

import service.AddAService;
import service.RepairService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

import static java.lang.System.out;


@WebServlet("/RepairServlet")
public class RepairServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public RepairServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");

        String Desc = request.getParameter("description");
        HttpSession session=request.getSession();
        String SID = (String) session.getAttribute("SID");
        String AID = (String) session.getAttribute("AID");
        String DorNum = (String) session.getAttribute("DorNum");

        out.println("RepairServlet receive "+Desc+AID+"#"+DorNum+SID);
        RepairService service =new RepairService();
        String res=service.Repair(SID,AID,DorNum,Desc);

        response.sendRedirect("index.jsp");

    }}
