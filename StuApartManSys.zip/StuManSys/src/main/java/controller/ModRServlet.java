package controller;

import service.ModAService;
import service.ModRService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/ModRServlet")
public class ModRServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String RID = request.getParameter("RID");
        System.out.println(RID);
        String status = request.getParameter("statuss");
        ModRService service =new ModRService();
        String res=service.ModR(RID,status);

        response.sendRedirect("ShowRServlet");

    }
}
