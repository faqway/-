package controller;

import service.DelService;
import service.ModAService;
import service.ModService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static java.lang.System.out;


@WebServlet("/ModAServlet")
public class ModAServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModAServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");

        String AID = request.getParameter("AID");
        String name= request.getParameter("name");
        String capacity= request.getParameter("Capacity");
        ModAService service =new ModAService();
        String res=service.ModApart(AID,name,capacity);

        response.sendRedirect("ModAShow");

    }
}
