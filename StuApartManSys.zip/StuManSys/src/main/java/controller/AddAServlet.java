package controller;

import service.AddAService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static java.lang.System.out;


@WebServlet("/AddAServlet")
public class AddAServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddAServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");

        String AID= request.getParameter("AID");
        String Location=request.getParameter("Location");
        String name= request.getParameter("name");
        String Capacity= request.getParameter("Capacity");
        AddAService service =new AddAService();
        String res=service.addApart(AID, Location,name,Capacity);

        out.println("Servlet receive "+AID+Location+name+Capacity);

        response.sendRedirect("AddAShow");

    }
}